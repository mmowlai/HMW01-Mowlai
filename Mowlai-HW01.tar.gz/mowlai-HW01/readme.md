ADM-HW01-Mowlai-1917906
Script folder:
a single .py file with all the scripts divided with commands
Submition folder:
stamps of all the submissions pages
